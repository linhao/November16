package edu.nyu.scps.november16;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;


public class YankeeView extends View {
	Context context;
	
	public YankeeView(Context context) {
		super(context);
		this.context = context;
	}
	
	@Override	
	protected void onDraw(Canvas canvas){
		final int width = getWidth();
		final int height = getHeight();
		
		canvas.drawColor(Color.WHITE);	//background 

		//draw yankees logo
		final Resources resources = context.getResources();
		final Bitmap bitMap = BitmapFactory.decodeResource(resources, R.drawable.nyy1335);
		final Bitmap bitMap2 = BitmapFactory.decodeResource(resources, R.drawable.got27);
		final Bitmap bitMap3 = BitmapFactory.decodeResource(resources, R.drawable.bosox);

		canvas.drawBitmap(bitMap, width/4, height/4, null);
		canvas.drawBitmap(bitMap2, width/2, height/3, null);	
		canvas.drawBitmap(bitMap3, width/4, height/2, null);
			
	}
}
